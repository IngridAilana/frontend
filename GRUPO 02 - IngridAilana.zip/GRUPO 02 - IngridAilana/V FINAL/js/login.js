$("#login2").val(localStorage.getItem("login"));
$("#senha2").val(localStorage.getItem("senhacadastro"));

document.getElementById("botaoinvisivel").addEventListener("click", function() {
    sessionStorage.setItem("login", $("#login2").val());
    sessionStorage.setItem("senhacadastro", $("#senha2").val());
    console.log("Logado!");
});

